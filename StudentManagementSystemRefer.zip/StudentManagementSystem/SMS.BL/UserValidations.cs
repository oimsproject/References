﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entity;
using SMS.Exeception;
using SMS.DAL;

namespace SMS.BL
{
    public class UserValidations
    {
        public static string ValidateUser(User user)
        {
            string username = "";

            try 
            {
                username = UserOperations.ValidateUser(user);
            }
            catch (UserException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return username;
        }
    }
}
