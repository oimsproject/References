﻿namespace SMS.PL
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtbAddress = new System.Windows.Forms.RichTextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblStudentNm = new System.Windows.Forms.Label();
            this.lblRoll = new System.Windows.Forms.Label();
            this.txtSName = new System.Windows.Forms.TextBox();
            this.rbFem = new System.Windows.Forms.RadioButton();
            this.rbMale = new System.Windows.Forms.RadioButton();
            this.lblDeptID = new System.Windows.Forms.Label();
            this.grpGender = new System.Windows.Forms.GroupBox();
            this.lstDept = new System.Windows.Forms.ListBox();
            this.dtpDOB = new System.Windows.Forms.DateTimePicker();
            this.dtgrd = new System.Windows.Forms.DataGridView();
            this.cbRoll = new System.Windows.Forms.ComboBox();
            this.btnCount = new System.Windows.Forms.Button();
            this.Update = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnInsert = new System.Windows.Forms.Button();
            this.lblContact = new System.Windows.Forms.Label();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.grpGender.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgrd)).BeginInit();
            this.SuspendLayout();
            // 
            // rtbAddress
            // 
            this.rtbAddress.Location = new System.Drawing.Point(229, 258);
            this.rtbAddress.Name = "rtbAddress";
            this.rtbAddress.Size = new System.Drawing.Size(198, 96);
            this.rtbAddress.TabIndex = 36;
            this.rtbAddress.Text = "";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(147, 290);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(45, 13);
            this.lblAddress.TabIndex = 34;
            this.lblAddress.Text = "Address";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(152, 120);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(30, 13);
            this.lblDate.TabIndex = 33;
            this.lblDate.Text = "DOB";
            // 
            // lblStudentNm
            // 
            this.lblStudentNm.AutoSize = true;
            this.lblStudentNm.Location = new System.Drawing.Point(147, 68);
            this.lblStudentNm.Name = "lblStudentNm";
            this.lblStudentNm.Size = new System.Drawing.Size(75, 13);
            this.lblStudentNm.TabIndex = 32;
            this.lblStudentNm.Text = "Student Name";
            // 
            // lblRoll
            // 
            this.lblRoll.AutoSize = true;
            this.lblRoll.Location = new System.Drawing.Point(147, 20);
            this.lblRoll.Name = "lblRoll";
            this.lblRoll.Size = new System.Drawing.Size(65, 13);
            this.lblRoll.TabIndex = 31;
            this.lblRoll.Text = "Student Roll";
            // 
            // txtSName
            // 
            this.txtSName.Location = new System.Drawing.Point(227, 61);
            this.txtSName.Name = "txtSName";
            this.txtSName.Size = new System.Drawing.Size(200, 20);
            this.txtSName.TabIndex = 30;
            // 
            // rbFem
            // 
            this.rbFem.AutoSize = true;
            this.rbFem.Location = new System.Drawing.Point(17, 50);
            this.rbFem.Name = "rbFem";
            this.rbFem.Size = new System.Drawing.Size(59, 17);
            this.rbFem.TabIndex = 20;
            this.rbFem.TabStop = true;
            this.rbFem.Text = "Female";
            this.rbFem.UseVisualStyleBackColor = true;
            // 
            // rbMale
            // 
            this.rbMale.AutoSize = true;
            this.rbMale.Location = new System.Drawing.Point(17, 26);
            this.rbMale.Name = "rbMale";
            this.rbMale.Size = new System.Drawing.Size(48, 17);
            this.rbMale.TabIndex = 19;
            this.rbMale.TabStop = true;
            this.rbMale.Text = "Male";
            this.rbMale.UseVisualStyleBackColor = true;
            // 
            // lblDeptID
            // 
            this.lblDeptID.AutoSize = true;
            this.lblDeptID.Location = new System.Drawing.Point(147, 436);
            this.lblDeptID.Name = "lblDeptID";
            this.lblDeptID.Size = new System.Drawing.Size(44, 13);
            this.lblDeptID.TabIndex = 35;
            this.lblDeptID.Text = "Dept ID";
            // 
            // grpGender
            // 
            this.grpGender.Controls.Add(this.rbFem);
            this.grpGender.Controls.Add(this.rbMale);
            this.grpGender.Location = new System.Drawing.Point(227, 167);
            this.grpGender.Name = "grpGender";
            this.grpGender.Size = new System.Drawing.Size(205, 73);
            this.grpGender.TabIndex = 29;
            this.grpGender.TabStop = false;
            this.grpGender.Text = "Gender";
            // 
            // lstDept
            // 
            this.lstDept.FormattingEnabled = true;
            this.lstDept.Location = new System.Drawing.Point(260, 425);
            this.lstDept.Name = "lstDept";
            this.lstDept.Size = new System.Drawing.Size(120, 95);
            this.lstDept.TabIndex = 28;
            this.lstDept.SelectedIndexChanged += new System.EventHandler(this.lstDept_SelectedIndexChanged);
            // 
            // dtpDOB
            // 
            this.dtpDOB.Location = new System.Drawing.Point(227, 120);
            this.dtpDOB.Name = "dtpDOB";
            this.dtpDOB.Size = new System.Drawing.Size(200, 20);
            this.dtpDOB.TabIndex = 27;
            // 
            // dtgrd
            // 
            this.dtgrd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgrd.Location = new System.Drawing.Point(461, 12);
            this.dtgrd.Name = "dtgrd";
            this.dtgrd.Size = new System.Drawing.Size(495, 488);
            this.dtgrd.TabIndex = 26;
            // 
            // cbRoll
            // 
            this.cbRoll.FormattingEnabled = true;
            this.cbRoll.Location = new System.Drawing.Point(259, 12);
            this.cbRoll.Name = "cbRoll";
            this.cbRoll.Size = new System.Drawing.Size(121, 21);
            this.cbRoll.TabIndex = 25;
            // 
            // btnCount
            // 
            this.btnCount.Location = new System.Drawing.Point(781, 559);
            this.btnCount.Name = "btnCount";
            this.btnCount.Size = new System.Drawing.Size(75, 23);
            this.btnCount.TabIndex = 24;
            this.btnCount.Text = "Count";
            this.btnCount.UseVisualStyleBackColor = true;
            this.btnCount.Click += new System.EventHandler(this.btnCount_Click);
            // 
            // Update
            // 
            this.Update.Location = new System.Drawing.Point(580, 559);
            this.Update.Name = "Update";
            this.Update.Size = new System.Drawing.Size(107, 23);
            this.Update.TabIndex = 23;
            this.Update.Text = "Update Details";
            this.Update.UseVisualStyleBackColor = true;
            this.Update.Click += new System.EventHandler(this.Update_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(422, 559);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 22;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(229, 559);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 21;
            this.button2.Text = "Delete";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnInsert
            // 
            this.btnInsert.Location = new System.Drawing.Point(75, 559);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(75, 23);
            this.btnInsert.TabIndex = 20;
            this.btnInsert.Text = "Insert";
            this.btnInsert.UseVisualStyleBackColor = true;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // lblContact
            // 
            this.lblContact.AutoSize = true;
            this.lblContact.Location = new System.Drawing.Point(152, 391);
            this.lblContact.Name = "lblContact";
            this.lblContact.Size = new System.Drawing.Size(44, 13);
            this.lblContact.TabIndex = 37;
            this.lblContact.Text = "Contact";
            // 
            // txtContact
            // 
            this.txtContact.Location = new System.Drawing.Point(229, 388);
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(198, 20);
            this.txtContact.TabIndex = 38;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(968, 609);
            this.Controls.Add(this.txtContact);
            this.Controls.Add(this.lblContact);
            this.Controls.Add(this.rtbAddress);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.lblStudentNm);
            this.Controls.Add(this.lblRoll);
            this.Controls.Add(this.txtSName);
            this.Controls.Add(this.lblDeptID);
            this.Controls.Add(this.grpGender);
            this.Controls.Add(this.lstDept);
            this.Controls.Add(this.dtpDOB);
            this.Controls.Add(this.dtgrd);
            this.Controls.Add(this.cbRoll);
            this.Controls.Add(this.btnCount);
            this.Controls.Add(this.Update);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnInsert);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpGender.ResumeLayout(false);
            this.grpGender.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgrd)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtbAddress;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblStudentNm;
        private System.Windows.Forms.Label lblRoll;
        private System.Windows.Forms.TextBox txtSName;
        private System.Windows.Forms.RadioButton rbFem;
        private System.Windows.Forms.RadioButton rbMale;
        private System.Windows.Forms.Label lblDeptID;
        private System.Windows.Forms.GroupBox grpGender;
        private System.Windows.Forms.ListBox lstDept;
        private System.Windows.Forms.DateTimePicker dtpDOB;
        private System.Windows.Forms.DataGridView dtgrd;
        private System.Windows.Forms.ComboBox cbRoll;
        private System.Windows.Forms.Button btnCount;
        private System.Windows.Forms.Button Update;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.Label lblContact;
        private System.Windows.Forms.TextBox txtContact;
    }
}

