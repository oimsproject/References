﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using SMS.Exception;
using SMS.Entity;
using SMS.BAL;

namespace SMS.PL
{
    public partial class Form1 : Form
    {
        StudentBAL bal = null;
        DepartmentBAL bl = null;
        List<StudentDetails> students = null;
        List<Department> dept = null;
        public Form1()
        {
            InitializeComponent();
            bal = new StudentBAL();
            bl = new DepartmentBAL();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            students = bal.GetAll(); //binding of Student data 
            dtgrd.DataSource = students;
            cbRoll.DataSource = students;
            cbRoll.DisplayMember = "Student_Roll";

            dept = bl.GetAll(); //binding of department data
            lstDept.DataSource = dept;
            lstDept.DisplayMember = "Dept_ID";


        }

        private void lstDept_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


        //INSERT STUDENTS
        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {


                StudentDetails sd = new StudentDetails();
                sd.Student_Name = txtSName.Text;

                sd.DOB = DateTime.Parse(dtpDOB.Text);

                if (rbMale.Checked)
                {
                    sd.Gender = "Male";
                }
                else if (rbFem.Checked)
                {
                    sd.Gender = "Female";
                }
                sd.Address = rtbAddress.Text;
                sd.Contact = txtContact.Text;
                sd.DeptID = int.Parse(lstDept.Text);

                if (bal.Add(sd))
                {
                    MessageBox.Show("Student Inserted!");
                }


                List<StudentDetails> studList = new List<StudentDetails>();
                studList = bal.GetAll();
                dtgrd.DataSource = studList;
            }
            catch(StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

            

        }

        private void button2_Click(object sender, EventArgs e) //delete students
        {
            
            StudentDetails student = new StudentDetails();
            if(bal.Remove(int.Parse(cbRoll.Text)))
            {
                MessageBox.Show("Student Deleted!");
                
            }
            List<StudentDetails> studList = new List<StudentDetails>();
            studList = bal.GetAll();
            dtgrd.DataSource = studList;
            MessageBox.Show("Student Deleted!");
        }

        //total Count
        private void btnCount_Click(object sender, EventArgs e)
        {
            int n = bal.TotalCount();
            MessageBox.Show("Total: " + n);
        }


        //Update Student Data
        private void Update_Click(object sender, EventArgs e)
        {
            try
            {
                StudentDetails sd = new StudentDetails();
                sd.Student_Roll = Convert.ToInt32(cbRoll.Text);
                sd.Student_Name = txtSName.Text;

                sd.DOB = DateTime.Parse(dtpDOB.Text);

                if (rbMale.Checked)
                {
                    sd.Gender = "Male";
                }
                else if (rbFem.Checked)
                {
                    sd.Gender = "Female";
                }
                sd.Address = rtbAddress.Text;
                sd.Contact = txtContact.Text;
                sd.DeptID = int.Parse(lstDept.Text);

                if (bal.Modify(sd))
                {
                    MessageBox.Show("Student Details Updated!!");
                }
                else
                    throw new StudentException("Record not Updated!");
                List<StudentDetails> studList = new List<StudentDetails>();
                studList = bal.GetAll();
                dtgrd.DataSource = studList;
            }
            catch(StudentException ex)
            {
                MessageBox.Show(ex.Message);

            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
                try{
                    int id = int.Parse(cbRoll.Text);
                    foreach (var item in students)
                    {
                        if(id== item.Student_Roll)
                        {
                            txtSName.Text = item.Student_Name;
                            if(item.Gender=="Male")
                            {
                                rbMale.Checked = true;
                            }
                            else if(item.Gender=="Female")
                            {
                                rbFem.Checked = true;
                            }
                            txtContact.Text = item.Contact;
                            rtbAddress.Text = item.Address;
                            dtpDOB.Text = item.DOB.ToString();
                            lstDept.Text = item.DeptID.ToString();
                            break;
                        }
                    }
                }
            catch(StudentException ex)
                {
                    MessageBox.Show("Student not found!!");
                }
            
            }

        }


    }

