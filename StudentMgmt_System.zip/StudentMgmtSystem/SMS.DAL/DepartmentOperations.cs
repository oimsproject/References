﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entity;
using System.Configuration;
using System.Data.SqlClient;

namespace SMS.DAL
{
    public class DepartmentOperations
    {

        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;
       
        public DepartmentOperations()
        {
            string cnStr = ConfigurationManager.ConnectionStrings["cn1"].ConnectionString;
            cn = new SqlConnection(cnStr);

        }

        public List<Department> SelectAll()
        {
            List<Department> Depts = new List<Department>();
            try
            {
                cmd = new SqlCommand("Select * from Department", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Department dept = new Department();
                    dept.Dept_ID = (int)dr[0];
                    dept.Dept_Nm = dr[1].ToString();
                    Depts.Add(dept);
                }
                dr.Close();
                cn.Close();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return Depts;
        }
    }
    
}
