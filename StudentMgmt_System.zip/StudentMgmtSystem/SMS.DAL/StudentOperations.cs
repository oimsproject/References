﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entity;
using SMS.Exception;
using System.Data.SqlClient;
using System.Configuration;

namespace SMS.DAL
{
    public class StudentOperations
    {

        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public StudentOperations()
        {
            string cnStr = ConfigurationManager.ConnectionStrings["cn1"].ConnectionString;

            cn = new SqlConnection(cnStr);
        }

        public List<StudentDetails> SelectAll()
        {
            List<StudentDetails> studentList = new List<StudentDetails>();

         try
                {
                    cmd = new SqlCommand("USP_SelectStudents_142308", cn);
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;

                    cn.Open();
                    dr = cmd.ExecuteReader();
                    //To Retreive the record with the help of data reader
                    while (dr.Read())
                    {
                        StudentDetails student = new StudentDetails();
                        student.Student_Roll =(int)dr[0];
                        student.Student_Name=dr[1].ToString();
                        student.DOB = (Convert.ToDateTime(dr[2]));
                        student.Gender=dr[3].ToString();
                        student.Address=dr[4].ToString();
                        student.Contact=dr[5].ToString();
                        student.DeptID = (int)dr[6];
                        studentList.Add(student);

                    }
                }
          catch (StudentException ex)
            {
                throw ex;
            }
           finally
            {
                dr.Close();
                cn.Close();
            }
            
            return studentList;
        }

        //insert
        public int InsertStudent(StudentDetails student)
        {
            int n;
            try
            {
                cmd = new SqlCommand("USP_InsertStudent_142308v",cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@sname", student.Student_Name);
                cmd.Parameters.AddWithValue("@dob", student.DOB);
                cmd.Parameters.AddWithValue("@gender", student.Gender);
                cmd.Parameters.AddWithValue("@address_student", student.Address);
                cmd.Parameters.AddWithValue("@contact", student.Contact);
                cmd.Parameters.AddWithValue("@dept_id", student.DeptID);


                cn.Open();
                n = cmd.ExecuteNonQuery();

            }
            catch (StudentException ex)
            {
                throw ex;
            }
                catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {

                cn.Close();
            }
            return n;
        }

        //update
        public void UpdateStudent(StudentDetails student)
        {
            try
            {
                cmd = new SqlCommand("USP_UpdateStudent_142308", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@rollno", student.Student_Roll);
                cmd.Parameters.AddWithValue("@sname", student.Student_Name);
                cmd.Parameters.AddWithValue("@dob", student.DOB);
                cmd.Parameters.AddWithValue("@gender", student.Gender);
                cmd.Parameters.AddWithValue("@address_student", student.Address);
                cmd.Parameters.AddWithValue("@contact", student.Contact);
                cmd.Parameters.AddWithValue("@dept_id", student.DeptID);

                //executing command
                cn.Open();
                cmd.ExecuteNonQuery();
                }
            catch(SqlException ex)
            {
                throw ex;
            }
            catch(StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            finally
            {
                cn.Close();
            }
        }

        //delete

        public void Delete(int rollno)
        {
            int n;
            try
            {
                cmd = new SqlCommand("USP_DeleteStudent_142308", cn);
                cmd.CommandType= System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("rollno", rollno);
                cn.Open();
               n= cmd.ExecuteNonQuery();
            }
            catch(StudentException ex)
            {
                throw ex;
            }
            finally
            {

                cn.Close();
            }

        }

        //Search Student Details

        public List<StudentDetails> SearchStudent(int roll)
        {
            List<StudentDetails> studentlist = new List<StudentDetails>();
            StudentDetails student = null;
            try
            {
                //cmd.CommandText = "USP_SearchStudent_142308";
                cmd = new SqlCommand("USP_SearchStudent_142308", cn);
                cmd.CommandType= System.Data.CommandType.StoredProcedure;
             
                cn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if(dr.HasRows)
                {
                    student = new StudentDetails();
                    dr.Read();
                    student.Student_Roll = (int)dr["rollno"];
                    student.Student_Name = dr["sname"].ToString();
                    student.DOB = Convert.ToDateTime(dr["dob"]);
                    student.Gender = dr["gender"].ToString();
                    student.Address = dr["student_address"].ToString();
                    student.Contact = dr["contact"].ToString();
                    student.DeptID = (int)dr["dept_id"];
                    studentlist.Add(student);
                }
                else
                    throw new StudentException("Records Not Found!!");

            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
           return studentlist;
        }

        //total count

public int GetTotalCount()
        {
            int n;
            try
            {
                cmd = new SqlCommand("Select Count(rollno) from StudentMgmt_142308",cn);
                cn.Open();
                n = (int)cmd.ExecuteScalar();
      }

    catch(StudentException ex)
            {
                throw ex;
            }

            finally
            {
                cn.Close();
            }
            return n;
        }

        }

    }

