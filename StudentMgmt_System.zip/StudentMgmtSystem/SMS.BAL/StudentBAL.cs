﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.DAL;
using SMS.Entity;
using SMS.Exception;
using System.Text.RegularExpressions;

namespace SMS.BAL
{
    public class StudentBAL
    {
        public static bool ValidateStudent(StudentDetails stud)
        {
            bool studValidate = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if(stud.Student_Name == string.Empty)
                {
                    studValidate = false;
                    message.Append("Name cannot be Empty!\n");
                }

                else if(!Regex.IsMatch(stud.Student_Name, "[A-Z][a-z]+"))
                {
                    studValidate = false;
                    message.Append("Name should only contain alphabets. The first letter should be capital.\n");
                }

                if(stud.DOB>=DateTime.Today)
                {
                    studValidate = false;
                    message.Append("Date of Birth cannot be greater than today's date!\n");
                }

                if(stud.Address==string.Empty)
                {
                    studValidate=false;
                    message.Append("Address cannot be empty!\n");
                }

                if(stud.Contact==null)
                {
                    studValidate = false;
                    message.Append("Phone number should not be null!\n ");
                }
                else if(!Regex.IsMatch(stud.Contact, "[7-9][0-9]{9}"))
                {
                    studValidate = false;
                    message.Append("Phone number should start with 7,8 or 9 and should contain 10 digits!!\n ");

                }
                if(studValidate==false)
                {
                    throw new StudentException(message.ToString());
                }

            }

            catch(StudentException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return studValidate;
        }
        
StudentOperations dal = null;
        public StudentBAL()
        {
            dal = new StudentOperations();
        }

        public List<StudentDetails> GetAll()
        {
            return dal.SelectAll();
        }


        //adding student method
        public bool Add(StudentDetails student)
        {
            bool studentInserted = false;

            try
            {
                if (ValidateStudent(student))
                {
                    
                    dal.InsertStudent(student);
                    studentInserted = true;

                }
                else
                    throw new StudentException("Please Provide valid Student Details!");


            }
            catch(StudentException ex)
            {
                throw ex;
            }


          
            return studentInserted;
        }

        //remove student method

        public bool Remove(int roll)
        {
           bool studentDeleted = false;
           
                 dal.Delete(roll);
                return studentDeleted;

        }



        //total count method
        public int TotalCount()
        {
            int IsCount = dal.GetTotalCount();
            return IsCount;
        }


        //update student data method
        public bool Modify (StudentDetails student)
        {
            bool studentModified = false;
            try
            {
                if (ValidateStudent(student))
                {
                    dal.UpdateStudent(student);
                    studentModified = true;
                }
                else
                    throw new StudentException("Student Details not updated!");
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return studentModified;
        }

        //function to search
        public List<StudentDetails> Search(int roll)
        {
          //  bool searchValidate = false;
            List<StudentDetails> st = new List<StudentDetails>();
           st= dal.SearchStudent(roll);
            return st;
        }
    }
}
