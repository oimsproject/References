﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entity;
using SMS.Exception;
using SMS.DAL;

namespace SMS.BAL
{
    public class DepartmentBAL
    {
        DepartmentOperations dal = null;

        public DepartmentBAL()
        {
            dal = new DepartmentOperations();
        }

        public List<Department> GetAll()
        {
            try
            {
                List<Department> depts = null;
                depts = dal.SelectAll();
            }
            catch (SystemException ex)
            {
                throw ex;
            }


            return dal.SelectAll();
        }
    }
    }

