﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using SMS.Entity;                 //Reference to User Entity
using SMS.Exeception;             //Reference to User Exception

namespace SMS.DAL
{
    /// <summary>
    /// Employee ID : 1422
    /// Employee Name : 
    /// Description : This a DAL Layer class for User Operations
    /// Date of Creation : 9th Feb 2018
    /// </summary>
    /// 

    public class UserOperations
    {
        public static string ValidateUser(User user)
        {
            string username = "";

            try 
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                //Assigning command text
                cmd.CommandText = "usp_ValidateUser";

                cmd.Parameters.AddWithValue("@uname", user.UserName);
                cmd.Parameters.AddWithValue("@pwd", user.Password);

                //Executing command
                cmd.Connection.Open();
                username = Convert.ToString(cmd.ExecuteScalar());
                cmd.Connection.Close();
            }
            catch (UserException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return username;
        }
    }
}