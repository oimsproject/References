﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using SMS.Entity;              //Reference to Student Entity
using SMS.Exeception;            //Reference to Student Exception

namespace SMS.DAL
{
    /// <summary>
    /// Employee ID : 1422
    /// Employee Name : 
    /// Description : This a DAL Layer class for Student Operations
    /// Date of Creation : 9th Feb 2018
    /// </summary>
    /// 

    public class StudentOperations
    {
        //Function to insert Student record in database
        public static int InsertStudent(Student stud)
        {
            int rowsAffected = 0;

            try 
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                //Assigning command text
                cmd.CommandText = "usp_InsertStudent_115022";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@scode", stud.StudCode);
                cmd.Parameters.AddWithValue("@sname", stud.StudName);
                cmd.Parameters.AddWithValue("@dcode", stud.DeptCode);
                cmd.Parameters.AddWithValue("@dob", stud.DOB);
                cmd.Parameters.AddWithValue("@address", stud.Address);

                //Executing command
                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        //Function to update Student record from database
        public static int UpdateStudent(Student stud)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                //Assigning command text
                cmd.CommandText = "usp_UpdateStudent_115022";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@scode", stud.StudCode);
                cmd.Parameters.AddWithValue("@dob", stud.DOB);
                cmd.Parameters.AddWithValue("@address", stud.Address);

                //Executing command
                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        //Function to delete student record from database
        public static int DeleteStudent(int scode)
        {
            int recordsAffected = 0;

            try 
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                //Assigning command text
                cmd.CommandText = "usp_DeleteStudent_115022";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@scode", scode);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        //Function to search student record based on Student Code
        public static Student SearchStudent(int scode)
        {
            Student stud = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                //Assigning command text
                cmd.CommandText = "usp_SearchStudent_115022";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@scode", scode);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    stud = new Student();
                    stud.StudCode = Convert.ToInt32(dr["Student_Code"]);
                    stud.StudName = dr["Student_name"].ToString();
                    stud.DeptCode = Convert.ToInt32(dr["dept_code"]);
                    stud.DOB = Convert.ToDateTime(dr["Stuent_dob"]);
                    stud.Address = dr["Student_Address"].ToString();
                }
                else
                {
                    throw new StudentException("Student not avaialble with code : " + scode);
                }
                cmd.Connection.Close();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }

        //Function to Display all student record
        public static List<Student> DisplayStudent()
        {
            List<Student> studList = null;

            try 
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_DisplayStudent_115022";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    studList = new List<Student>();

                    while (dr.Read())
                    {
                        Student stud = new Student();
                    
                        stud.StudCode = Convert.ToInt32(dr["Student_Code"]);
                        stud.StudName = dr["Student_name"].ToString();
                        stud.DeptCode = Convert.ToInt32(dr["dept_code"]);
                        stud.DOB = Convert.ToDateTime(dr["Stuent_dob"]);
                        stud.Address = dr["Student_Address"].ToString();

                        studList.Add(stud);
                    }
                }
                else
                    throw new StudentException("Student Details not Available");
                cmd.Connection.Close();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studList;
        }
    }
}
