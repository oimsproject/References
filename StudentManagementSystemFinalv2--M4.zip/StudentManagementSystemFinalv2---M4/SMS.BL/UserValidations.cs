﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entity;              //Reference to User Entity
using SMS.Exeception;           //Reference to User Exception
using SMS.DAL;                   //Reference to User Operations

namespace SMS.BL
{
    /// <summary>
    /// Employee ID : 1422
    /// Employee Name : 
    /// Description : This a BAL Layer class for User Validations
    /// Date of Creation : 9th Feb 2018
    /// </summary>
    /// 

    public class UserValidations
    {
        //Method to validate user details
        public static string ValidateUser(User user)
        {
            string username = "";

            try 
            {
                username = UserOperations.ValidateUser(user);
            }
            catch (UserException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return username;
        }
    }
}
