﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Entity
{
    /// <summary>
    /// Employee ID : 1422
    /// Employee Name : 
    /// Description : This an entity class for User
    /// Date of Creation : 9th Feb 2018
    /// </summary>
    /// 

    public class User
    {
        //Get or Set UserName
        public string UserName { get; set; }

        //Get or Set Password
        public string Password { get; set; }
    }
}
