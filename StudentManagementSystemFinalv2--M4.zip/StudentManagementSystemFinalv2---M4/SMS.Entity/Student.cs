﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Entity
{
    /// <summary>
    /// Employee ID : 1422
    /// Employee Name : 
    /// Description : This an entity class for Student
    /// Date of Creation : 9th Feb 2018
    /// </summary>
    /// 

    public class Student
    {
        //Get or Set Student Code
        public int StudCode { get; set; }

        //Get or Set Student Name
        public string StudName { get; set; }

        //Get or Set Department Code
        public int DeptCode { get; set; }

        //Get or Set Date Of Birth
        public DateTime DOB { get; set; }

        //Get or Set Address
        public string Address { get; set; }
    }
}
