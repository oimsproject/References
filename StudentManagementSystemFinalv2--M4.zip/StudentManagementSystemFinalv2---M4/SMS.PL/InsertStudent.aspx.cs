﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entity;                   //Reference to Student Entity
using SMS.Exeception;                //Reference to Student Exception
using SMS.BL;                        //Reference to Student Validations

namespace SMS.PL
{
    public partial class InsertStudent : System.Web.UI.Page
    {
        Student stud = new Student();

        //Method for Page Load Event
        protected void Page_Load(object sender, EventArgs e)
        {

            ddlDeptCode.DataSource = StudentValidations.DisplayStudent();
            ddlDeptCode.DataTextField = "DeptCode";
            ddlDeptCode.DataBind();            

            if (Session["user"] != null)
            {

                Master.Logout = true;
                Master.Menu = true;
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        //Method for Insert Button Click Event
        protected void btnInsert_Click(object sender, EventArgs e)
        {         
            try
            {
                stud.StudCode = Convert.ToInt32(txtCode.Text);
                stud.StudName = txtName.Text;
                stud.DeptCode = Convert.ToInt32(ddlDeptCode.Text);
                stud.DOB = Convert.ToDateTime(txtDob.Text);
                stud.Address = txtAddress.Text;

                string str = Convert.ToString(StudentValidations.InsertStudent(stud));
                int s;
                bool b = int.TryParse(str, out s);
                if (b)
                {
                    Response.Write("<script>alert('Student Inserted Sucessfully');</script>");
                }
                else
                {
                    Response.Write("<script>alert('Record not Inserted');</script>");
                }    
            }
            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }

    }
}