﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Exeception
{
    /// <summary>
    /// Employee ID : 1422
    /// Employee Name : 
    /// Description : This an Exception class for User
    /// Date of Creation : 9th Feb 2018
    /// </summary>
    ///

    public class UserException:ApplicationException
    {
        //Default Constructor
        public UserException()
            : base()
        { }

        //Parameterized Constructor
        public UserException(string message)
            : base(message)
        { }
    }
}
