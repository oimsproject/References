﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Exeception
{
    /// <summary>
    /// Employee ID : 1422
    /// Employee Name : 
    /// Description : This an Exception class for Student
    /// Date of Creation : 9th Feb 2018
    /// </summary>
    ///

    public class StudentException : ApplicationException
    {
        //Default Constructor
        public StudentException()
            : base()
        { }

        //Parameterized Constructor
        public StudentException(string message)
            : base(message)
        { }
    }
}
