﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entity;
using SMS.Exeception;
using SMS.BL;

namespace SMS.PL
{
    public partial class InsertStudent : System.Web.UI.Page
    {
        Student stud = new Student();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != null)
            {

                Master.Logout = true;
                Master.Menu = true;
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
           
            try
            {

                stud.StudCode = Convert.ToInt32(txtCode.Text);

                stud.StudName = txtName.Text;

                stud.DeptCode = Convert.ToInt32(txtDeptCode.Text);

                stud.DOB = Convert.ToDateTime(txtDob.Text);

                stud.Address = txtAddress.Text;

                StudentValidations.InsertStudent(stud);

                Response.Write("<script>alert('Student Inserted Sucessfully');</script>");

            }
            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }


    }
}