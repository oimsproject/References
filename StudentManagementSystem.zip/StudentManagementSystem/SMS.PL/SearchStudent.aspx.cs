﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entity;
using SMS.Exeception;
using SMS.BL;

namespace SMS.PL
{
    public partial class SearchStudent : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["user"] != null)
            {

                Master.Logout = true;
                Master.Menu = true;
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            Student stud = null;
            int scode = Convert.ToInt32(txtStudCode.Text);

            try 
            {
                    stud = StudentValidations.SearchStudent(scode);
 
                    txtName.Text = stud.StudName;
                    txtName.DataBind();

                    txtDeptCode.Text = stud.DeptCode.ToString();
                    txtDeptCode.DataBind();
                    
                    txtDob.Text = stud.DOB.ToString();
                    txtDob.DataBind();
                    
                    txtAddress.Text = stud.Address;
                    txtAddress.DataBind();

            }
            catch(StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch(SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {

            Student stud = null;
            
            try
            {
                int scode = Convert.ToInt32(txtStudCode.Text);
                stud = StudentValidations.SearchStudent(scode); 

                stud.StudCode = Convert.ToInt32(txtStudCode.Text);

                stud.StudName = txtName.Text;
                
                stud.DeptCode = Convert.ToInt32(txtDeptCode.Text);

                stud.DOB = Convert.ToDateTime(txtDob.Text);

                stud.Address = txtAddress.Text;

                StudentValidations.UpdateStudent(stud);
                Response.Write("<script>alert('Student Updated Sucessfully');</script>");

            }
            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            
            try
            {
                
                StudentValidations.DeleteStudent(Convert.ToInt32(txtStudCode.Text));
                Response.Write("<script>alert('Student Deleted Sucessfully');</script>");
            }
            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }


    }
}