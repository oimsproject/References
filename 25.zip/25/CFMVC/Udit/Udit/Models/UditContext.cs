﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace Udit.Models
{
    public class UditContext: DbContext
    {

        public UditContext():base("con")
        {

        }

        public DbSet<U2> U2s { get; set; }
    }

}