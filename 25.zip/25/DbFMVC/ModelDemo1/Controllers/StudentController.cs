﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using ModelDemo1.Models;
namespace ModelDemo1.Controllers
{
    public class StudentController : Controller
    {
        // GET: Student
        public ActionResult Index()
        {
            
            Entities context = new Entities();
            
            var query = from student in context.Student_Master
                        where student.Student_Address == null
                        select student;

            return View(query);
        }
    }
}