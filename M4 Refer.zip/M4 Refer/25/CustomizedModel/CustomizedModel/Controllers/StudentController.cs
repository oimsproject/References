﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CustomizedModel.Models;
using System.Net;
using System.Data.Entity;
using System.Data;

namespace CustomizedModel.Controllers
{
    public class StudentController : Controller
    {
        Training context = new Training();
        // GET: Student
        public ActionResult Index()
        {
            var data = context.Student_Master;
            return View(data);
        }

        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(Student_Master student)
        {
            if (ModelState.IsValid)
            {
                context.Student_Master.Add(student);
                context.SaveChanges();

                return RedirectToAction("Index");
            }
            return View(student);
        }

        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            Student_Master student = context.Student_Master.Find(id);
            return View(student);
        }

        [HttpPost]
        public ActionResult Edit(Student_Master student)
        {
            if (ModelState.IsValid)
            {
                context.Entry(student).State = System.Data.Entity.EntityState.Modified;
                context.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(student);
        }

        public ActionResult Delete(int? id)
        {
            {
                if (id == null)
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);


                Student_Master student = context.Student_Master.Find(id);
                return View(student);



            }
        }
        [ActionName("Delete")]
        [HttpPost]
        public ActionResult DeleteConfirmed(int? id)
        {
            var student = context.Student_Master.Find(id);

            context.Student_Master.Remove(student);
            context.SaveChanges();

            return RedirectToAction("Index");
        }

        public ActionResult Details(int? id)
        {
            var student = context.Student_Master.Find(id);

            return View(student);
        }

        public ActionResult GetStudentsPune1980()
        {
            var data = from student in context.Student_Master
                       where student.Student_Address.ToUpper() == "PUNE" && student.Stuent_dob.Value.Year == 1980
                       select student;

            return View(data);
        }
    }
}