﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BMS.BAL;
using BMS.Entity;
using BookException;

namespace BookMgmt
{
    public partial class Searchbooks : System.Web.UI.Page
    {
      
        static List<BookDetails> blist = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            blist = BookValidations.DisplayBook();
            if (!IsPostBack)
            {
                if (blist.Count > 0)
                {
                    ddlCode.DataSource = blist;

                    ddlCode.DataValueField = "BookCode";
                    ddlCode.DataMember = "BookCode";
                    ddlCode.DataBind();
                }

            }

            if (Session["user"] != null)
            {

                Master.Logout = true;
                Master.Menu = true;
            }
            else
            {
                Response.Redirect("Login.aspx");
            }

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if (this.IsPostBack)
            {
                btnUpdate.Visible = true;
                btnDelete.Visible = true;
                btnUpdate.Enabled = true;
                btnDelete.Enabled = true;

            }
            int bcode = Convert.ToInt32(ddlCode.Text);
            //int bcode = Convert.ToInt32(txtBookCode.Text);
            try
            {
              BookDetails book = new BookDetails();
                book = BookValidations.BookSearch(bcode);
                txtBookCode.Text = book.BookCode.ToString();
                txtName.Text = book.BookName;
                txtName.DataBind();
                txtPub.Text = book.PubYear.ToString();
                txtPub.DataBind();
                txtAuthor.Text = book.AuthorNm;
                txtAuthor.DataBind();
                txtCat.Text = book.BCategory;
                txtCat.DataBind();
            }
            catch (BookExceptions ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }  

        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {

            try
            {
                BookDetails book = new BookDetails();
               book.BookCode = int.Parse(txtBookCode.Text);
                book.BookName = txtName.Text;
                book.PubYear = Convert.ToDateTime(txtPub.Text);
                book.AuthorNm = txtAuthor.Text;
                book.BCategory = txtCat.Text;


                int n = BookValidations.UpdateBook(book);
                if (n > 0)
                {
                    Response.Write("<script>alert('Updated Sucessfully');</script>");
                }
                else
                {
                    Response.Write("<script>alert('Record not Updated');</script>");
                }
            }
            catch (BookExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {

            try
            {
                BookDetails book = new BookDetails();
                int bcode = Convert.ToInt32(ddlCode.Text);
                int n = BookValidations.DeleteBook(bcode);
                if (n > 0)
                {
                    Response.Write("<script>alert('" + "Deleted" + "');</script>");


                }
                else
                    throw new BookExceptions("Book Details Not Available");
            }
            catch (BookExceptions ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }
    }
}