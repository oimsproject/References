﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BMS.BAL;
using BMS.Entity;
using BookException;


namespace BookMgmt
{
    public partial class InsertBook : System.Web.UI.Page
    {
        BookDetails book= new BookDetails();
     
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["user"]!=null)
            {
                Master.Logout = true;
                Master.Menu = true;
            }

            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void ddlGenre_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                book.BookCode = Convert.ToInt32(txtCode.Text);
                book.BookName = txtName.Text;
                book.PubYear = Convert.ToDateTime(txtPub.Text);
                book.AuthorNm = txtAuthor.Text;
                book.BCategory = ddlGenre.SelectedItem.Text;
                int n = BookValidations.InsertBook(book);
                if(n>0)
                {
                    Response.Write("<script>alert(' Registered  successfully!');");
                    Response.Write("window.location='Home.aspx'</script>");
                }}
  catch (BookExceptions ex)
            {
                Response.Write(ex.Message);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            }
        }
    }
