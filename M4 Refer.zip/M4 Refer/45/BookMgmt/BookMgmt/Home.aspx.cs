﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BMS.Entity;
using BMS.BAL;
using BookException;

namespace BookMgmt
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["user"]!=null)
            {
                lblHome.Text = "Annyeong " + Session["user"].ToString();
                Master.Logout = true;
                Master.Menu = true;
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
            try
            {
                List<BookDetails> bookList = BookValidations.DisplayBook();
                if (bookList.Count > 0)
                {
                    gvBook.DataSource = bookList;
                    gvBook.DataBind();
                    
                }
                else
                    throw new BookExceptions("No records found!");
            }
            catch(BookExceptions ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>"); 
            }
            catch(SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }
    }
}