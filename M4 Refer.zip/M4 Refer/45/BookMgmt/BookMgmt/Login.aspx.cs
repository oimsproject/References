﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BMS.Entity;
using BMS.BAL;
using BookException;

namespace BookMgmt
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                Users user = new Users();
                user.UserNm = txtUserName.Text;
                user.UPwd = txtPassword.Text;
                string uname = UserValidations.ValidateUser(user);

                if(uname== String.Empty || uname==null)
                {
                    lblError.Text = "Invalid Username / Password";
                }
                  else 
                {
                    Session["user"] = uname;
                    Response.Redirect("Home.aspx");
                }
            }
            catch (UserException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            }

        }
    }
