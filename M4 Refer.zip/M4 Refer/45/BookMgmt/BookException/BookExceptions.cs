﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookException
{
    public class BookExceptions : ApplicationException
    {
        public BookExceptions():base()
        {

        }

        public BookExceptions(string message) : base(message) { }
    }
}
