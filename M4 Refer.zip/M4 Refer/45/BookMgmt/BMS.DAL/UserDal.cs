﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BMS.Entity;
using BookException;
using System.Data;
using System.Data.SqlClient;

namespace BMS.DAL
{
   public class UserDal
    {
       public static string ValidateUser(Users user)
       {
           string usernm = "";
           try
           {
               
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_UserValidate";

                cmd.Parameters.AddWithValue("@UserNm", user.UserNm);
                cmd.Parameters.AddWithValue("@UPwd", user.UPwd);

                cmd.Connection.Open();
                usernm = Convert.ToString(cmd.ExecuteScalar());
                cmd.Connection.Close();
            }
            catch (UserException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return usernm;
        }
           }
       }
    

