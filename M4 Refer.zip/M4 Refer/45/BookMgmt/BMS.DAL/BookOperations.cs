﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using BMS.Entity;
using BookException;

namespace BMS.DAL
{
    public class BookOperations
    {
        public static int InsertBook(BookDetails book)
        {
            int rowsAffected = 0;
            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_BookInsert_";
                cmd.Parameters.AddWithValue("@BookCode", book.BookCode);
                cmd.Parameters.AddWithValue("@BookName", book.BookName);
                cmd.Parameters.AddWithValue("@PubYear", book.PubYear);
                cmd.Parameters.AddWithValue("@AuthorNm", book.AuthorNm);
                cmd.Parameters.AddWithValue("@BCategory", book.BCategory);
                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (BookExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return rowsAffected;

        }

        public static List<BookDetails> DisplayBooks()
        {
            List<BookDetails> bookList = null;
            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_BookShow";
                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    bookList = new List<BookDetails>();
                    while (dr.Read())
                    {


                        BookDetails bd = new BookDetails();
                        bd.BookCode = Convert.ToInt32(dr["BookCode"]);
                        bd.BookName = dr["BookName"].ToString();
                        bd.PubYear = Convert.ToDateTime(dr["PubYear"]);
                        bd.AuthorNm = dr["AuthorNm"].ToString();
                        bd.BCategory = dr["BCategory"].ToString();

                        bookList.Add(bd);
                    }
                }
                else
                    throw new BookExceptions("Book Details not available!");
                cmd.Connection.Close();

            }
            catch (BookExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return bookList;
        }

        public static BookDetails SearchBook(int bcode)
        {
            BookDetails b = null;
            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_BookSearch";
                cmd.Parameters.AddWithValue("@BookCode", bcode);
                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if(dr.HasRows)
                {
                    dr.Read();
                    b = new BookDetails();
                    b.BookCode=  Convert.ToInt32(dr["BookCode"]);
                        b.BookName = dr["BookName"].ToString();
                        b.PubYear = Convert.ToDateTime(dr["PubYear"]);
                        b.AuthorNm = dr["AuthorNm"].ToString();
                        b.BCategory = dr["BCategory"].ToString();
                }
                else
                {
                    throw new BookExceptions("No Records Found with the Book Code: " + bcode + "!");

                }

            }

            catch(BookExceptions ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return b;
        }


        public static int DeleteBook(int bid) 
        {
            int n = 0;
            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_BookDelete";
                cmd.Parameters.AddWithValue("@BookCode",bid);
                cmd.Connection.Open();
                n = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch(BookExceptions ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return n;
        }

        public static int UpdateBook(BookDetails book)
        {
            int n=0;
            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "USP_BookUpdatesvv";
                cmd.Parameters.AddWithValue("@BookCode", book.BookCode);
                cmd.Parameters.AddWithValue("@BookName", book.BookName);
                cmd.Parameters.AddWithValue("@PubYear", book.PubYear);
                cmd.Parameters.AddWithValue("@AuthorNm", book.AuthorNm);
                cmd.Parameters.AddWithValue("@BCategory", book.BCategory);
              
                cmd.Connection.Open();
                n = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch(BookExceptions ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return n;
        }
    }
}
