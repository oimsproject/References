﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BMS.Entity
{
    public class BookDetails
    {
        public int BookCode { get; set; }
        public string BookName { get; set; }
        public DateTime PubYear { get; set; }
        public string AuthorNm { get; set; }
        public string BCategory { get; set; }
    }
}
