﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BMS.Entity;
using BMS.DAL;
using BookException;


namespace BMS.BAL
{
    public class UserValidations
    {
        public static string ValidateUser(Users user)
        {
            string username = "";
            try
            {
                username = UserDal.ValidateUser(user);
            }
            catch(UserException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return username;
        }
    }
}
