﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BMS.DAL;
using BMS.Entity;
using BookException;

namespace BMS.BAL
{
    public class BookValidations
    {
        public static int InsertBook(BookDetails book)
        {
            int rowsAffected = 0;
            try
            {
                rowsAffected = BookOperations.InsertBook(book);
            }
            catch (BookExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return rowsAffected;
        }

        public static List<BookDetails> DisplayBook()
        {
            List<BookDetails> blist = null;
            try
            {
                blist = BookOperations.DisplayBooks();
            }
            catch (BookExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return blist;
        }

        public static BookDetails BookSearch(int bcode)
        {
            BookDetails b = null;
            try
            {
                b = BookOperations.SearchBook(bcode);
            }
            catch (BookExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return b;
        }

        public static int DeleteBook(int bcode)
        {
            int rowsAffected = 0;
            try
            {
                rowsAffected = BookOperations.DeleteBook(bcode);

            }
            catch (BookExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            { throw ex; }
            return rowsAffected;

        }

        public static int UpdateBook(BookDetails book)
        {
            int n;
            try
            {
                n = BookOperations.UpdateBook(book);
            }
            catch(BookExceptions ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return n;
        }
    }
}
