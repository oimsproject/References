﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using SMS.Entity;
using SMS.Exeception;

namespace SMS.DAL
{
    public class UserOperations
    {
        public static string ValidateUser(User user)
        {
            string username = "";

            try 
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_ValidateUser";

                cmd.Parameters.AddWithValue("@uname", user.UserName);
                cmd.Parameters.AddWithValue("@pwd", user.Password);

                cmd.Connection.Open();
                username = Convert.ToString(cmd.ExecuteScalar());
                cmd.Connection.Close();
            }
            catch (UserException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return username;
        }
    }
}