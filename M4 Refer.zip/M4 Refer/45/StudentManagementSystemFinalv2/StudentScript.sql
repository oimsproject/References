CREATE TABLE LoginUser
(
	username VARCHAR(20),
	password VARCHAR(20)
)

INSERT INTO LoginUser(username, password) VALUES('admin', 'admin')
GO
CREATE PROC usp_ValidateUser
(
	@uname		VARCHAR(20),
	@pwd		VARCHAR(20)
)
AS
BEGIN
	SELECT username 
	FROM LoginUser 
	WHERE username=@uname AND password=@pwd
END
GO

CREATE PROC usp_InsertStudent_115022
(
	@scode		INT,
	@sname		VARCHAR(40),
	@dcode		INT,
	@dob		DATE,
	@address	VARCHAR(50)
)
AS
BEGIN
	INSERT INTO Student_Master(Student_Code, Student_name, Dept_Code, Stuent_dob,Student_Address)
	VALUES(@scode, @sname, @dcode, @dob, @address)
END
GO
CREATE PROC usp_UpdateStudent_115022
(
	@scode		INT,
	@dob		DATE,
	@address	VARCHAR(50)
)
AS
BEGIN
	UPDATE Student_Master
	SET Stuent_dob = @dob,
		Student_Address = @address
	WHERE Student_Code = @scode
END

GO

CREATE PROC usp_DeleteStudent_115022
(
	@scode	INT
)
AS
BEGIN
	DELETE FROM Student_Master WHERE Student_Code = @scode
END

GO
CREATE PROC usp_SearchStudent_115022
(
	@scode	INT
)
AS
BEGIN
	SELECT * FROM Student_Master WHERE Student_Code = @scode
END

GO
CREATE PROC usp_DisplayStudent_115022
AS
BEGIN
	SELECT * FROM Student_Master
END