﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.Entity;
using EMS.Exception;
using EMS_BAL;

namespace WEB.PL
{
    public partial class Insert : System.Web.UI.Page
    {
        int gender = 0;
        EmployeeValidation ebal = null;
        Employee_Entity emp = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != null)
            {
                //lblWelcome.Text = "Welcome " + Session["user"].ToString();
                Master.Logout = true;
                Master.Menu = true;
            }
            else
            {
                Response.Redirect("Login.aspx");
            }

            ebal = new EmployeeValidation();
            emp = new Employee_Entity();
        }

        //Pl Layer method to Insert Employee Details
        protected void btnInsert(object sender, EventArgs e)
        {
            int recordsAffected = 0;
            try
            {
                int id = 0;
                if (int.TryParse(txtEmpId.Text, out id)) { }
                emp.EmpId = id;
                emp.EmpName = txtEmpName.Text;
                emp.DOJ = Convert.ToDateTime(txtDOJ.Text);
                decimal sid = 0;
                if (decimal.TryParse(txtSalary.Text, out sid)) { }
                emp.Salary = sid;
                int did = 0;
                if (int.TryParse(txtDeptCode.Text, out did)) { }
                emp.DeptId = did;
                if (gender == 1)
                {
                    emp.Gender = "Female";
                }
                else if(gender == 2)
                {
                    emp.Gender = "Male";
                }
                    
                recordsAffected = ebal.InsertEmployee(emp);
                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Employee Details are Successfully Inserted')</script>");
                }
                else
                    throw new Employee_Exception("<script>alert('Employee Details are not Successfully Inserted')</script>");

            }
            catch(Employee_Exception ex)
            {
                lblError.Text = ex.Message;
                Response.Write("<script>alert('" + lblError.Text + "')</script>");
                
                
            }
            catch(SystemException ex)
            {
                lblError.Text = ex.Message;
                Response.Write("<script>alert('" + lblError.Text +" ')</script>");
            }
            
        }

        protected void rblist_SelectedIndexChanged(object sender, EventArgs e)
        {
            gender =int.Parse(rblGender.SelectedValue);
        }
    }
}