﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using EMS.Entity;
using EMS.Exception;
using EMS.DAL;

namespace EMS_BAL
{
    public class EmployeeValidation
    {
        EmployeeOperations empop = new EmployeeOperations();

        public bool ValidateEmployee(Employee_Entity emp)
        {
            bool empValidated = true;
            //StringBuilder message = new StringBuilder();

            //try
            //{
            //    if(emp.EmpId < 100 || emp.EmpId > 999)
            //    {
            //        message.Append("Employee Id should be 3 digits\n");
            //        empValidated = false;
            //    }
            //    if(emp.EmpName == String.Empty)
            //    {
            //        empValidated = false;
            //        message.Append("Employee Name should be provided\n");
            //    }
            //    else if(!Regex.IsMatch(emp.EmpName, "[A-Z][a-z]+"))
            //    {
            //        message.Append("Employee Name should start with capital alphabet and it should have alphabets only\n\n");
            //        empValidated = false;
                    
            //    }
            //    if(emp.DOJ >= DateTime.Today)
            //    {
            //        message.Append("Employee Date of Joining should be less than current date\n");
            //        empValidated = false;
                    
            //    }
            //    if(emp.Salary < 0)
            //    {
            //        message.Append("Salary Should be provided\n");
            //        empValidated = false;
            //    }
            //    else if(emp.Salary < 10000)
            //    {
            //        message.Append("Salary should be greater than 10000 rupees\n");
            //        empValidated = false;
            //    }

            //    if (emp.DeptId < 10 || emp.DeptId > 99)
            //    {
            //        message.Append("Department Id should be 2 digits\n");
            //        empValidated = false;
            //    }

            //    if(empValidated == false)
            //        throw new Employee_Exception(message.ToString());

            //}
            //catch (Employee_Exception ex)
            //{
            //    throw ex;
            //}
            //catch (SystemException ex)
            //{
            //    throw ex;
            //}
            return empValidated;

        }

        public  int InsertEmployee(Employee_Entity emp)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidateEmployee(emp))
                {
                    recordsAffected = empop.InsertEmployee(emp);
                }
                else
                    throw new Employee_Exception("Please Provide valid Employee Information");
            }
            catch(Employee_Exception ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        //update Employee
        public  int UpdateEmployee(Employee_Entity emp)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidateEmployee(emp))
                {
                    recordsAffected = empop.UpdateEmployee(emp);
                }
                else
                    throw new Employee_Exception("Please Provide valid Employee Information");
            }
            catch (Employee_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        //delete employee
        public  int DeleteEmployee(int empid)
        {
            
            int recordsAffected = 0;

            try
            {
                recordsAffected = empop.DeleteEmployee(empid);
              
            }
            catch (Employee_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        //dIsplay employee
        public  List<Employee_Entity> DisplayAll()
        {
            List<Employee_Entity> empList = null;

            try
            {
                empList = empop.DisplayAll();
            }
            catch(Employee_Exception ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return empList;
        }

        //Total Count
        public int TotalCount(Employee_Entity emp)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = empop.TotalCountEmployee(emp);

            }
            catch(Employee_Exception ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            
            return recordsAffected;
        }

        //Search Employee Record
        public Employee_Entity SearchEmployee(int empid)
        {
            Employee_Entity emp = null;
            try
            {
                emp = empop.SearchEmployee(empid);
            }
            catch(Employee_Exception ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return emp;

        }
    }
}
